# Supplementary materials

## Accompanying manuscript

**Six-Month Change and Follow-up Patterns in AbilityScore During Routine Paediatric Developmental Care in India: Protocol for the PINNACLE-TRAJ Retrospective Multicentre Cohort Study**

Author: Koti Reddy Saripalli.

Package date: 15 September 2026.

Two protocol schematics and their captions accompany the PINNACLE-TRAJ retrospective multicentre cohort protocol. They illustrate planned cohort derivation and the primary-endpoint window. They contain no participant records, study counts, trajectories or outcome values.

## Contents and use

- `figures/Figure_1` and `figures/Figure_2`: each figure in SVG, EPS, PNG and TIFF formats. SVG and EPS are vector formats; PNG is convenient for viewing; TIFF is a raster publication format.
- `figures/Figure_Captions.md`: exact captions from the final manuscript figure package.
- `SHA256SUMS.txt`: SHA-256 checksums for every other file in this archive, using paths relative to this package folder.

Use these supplements with the accompanying manuscript, which supplies the full methods, interpretation, declarations and references. The repository record supplies the publication identifier and reuse terms for this release.
