# Figure captions

Six-Month Change and Follow-up Patterns in AbilityScore During Routine Paediatric Developmental Care in India: Protocol for the PINNACLE-TRAJ Retrospective Multicentre Cohort Study

## Figure 1. Planned cohort derivation and primary-outcome availability

Protocol schematic only; no study counts are displayed. Candidate routine records pass through deployment-defined centre/version eligibility, deduplication and baseline eligibility. Children remain in the cohort whether a comparable primary-window score is observed or unavailable. The reporting flow will explain unavailable scores, including a separate undefined-outcome category for any recorded death, and reconcile every branch to the baseline denominator.

## Figure 2. Primary endpoint and complete follow-up opportunity

Protocol illustration only. Baseline is day 0; the primary endpoint is the comparable score nearest day 180 within the inclusive day 150–210 window, with earlier-date ties. A child without a score in that window remains in the baseline cohort. With a proposed database close of 30 June 2026, a baseline must be on or before 2 December 2025 to permit the entire 210-day window. No trajectory or outcome values are shown.
