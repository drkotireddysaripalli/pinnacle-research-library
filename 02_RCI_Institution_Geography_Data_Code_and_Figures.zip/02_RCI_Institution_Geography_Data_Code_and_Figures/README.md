# Supplementary materials

## Accompanying manuscript

**Geographic Concentration of RCI-Listed Rehabilitation Training Institutions in India: A Reproducible National Register Analysis**

Author: Koti Reddy Saripalli.

Package date: 15 September 2026.

Two publication figures, captions and an audited institution-geography dataset accompany the national register analysis. The data contain 1,068 distinct RCI institution codes in the 4 February 2026 source snapshot. They describe listed institutions and geographic concentration, not current course capacity, professional supply or population-adjusted access.

## Contents and use

- `figures/Figure_1` and `figures/Figure_2`: each figure in SVG, EPS, PNG and TIFF formats. SVG and EPS are vector formats; PNG is convenient for viewing; TIFF is a raster publication format.
- `figures/Figure_Captions.md`: exact captions from the final manuscript figure package.
- `SHA256SUMS.txt`: SHA-256 checksums for every other file in this archive, using paths relative to this package folder.
- `data/`: audited institution records, geographic summaries, figure coordinates, source and validation metadata, label crosswalk, extraction correction log, complete reproduction code and a pinned dependency. Begin with `data/README.md` for definitions, limitations and reproduction commands. The correction log and crosswalk document the public-source data transformation.

The source government PDF is referenced by official URL and checksum in `data/workforce_source_manifest.json`; it is not redistributed here. The reproduction script accepts a local copy or downloads the specified source.

Use these supplements with the accompanying manuscript, which supplies the full methods, interpretation, declarations and references. The repository record supplies the publication identifier and reuse terms for this release.
