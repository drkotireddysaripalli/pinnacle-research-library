# Figure captions

Geographic Concentration of RCI-Listed Rehabilitation Training Institutions in India: A Reproducible National Register Analysis

## Figure 1. Geographic distribution of listed institutions

Number of distinct RCI institution codes by state or union territory in the 4 February 2026 source. All 36 jurisdictions are shown, including four with no entry. Bars represent register entries, not current training seats, active professionals or rates per population. Source: workforce_state_counts.csv.

## Figure 2. Concentration of listed institutions across jurisdictions

Lorenz curve for institution-code counts across all 36 states and union territories, ordered from the smallest to the largest count. The horizontal axis shows the cumulative share of jurisdictions and the vertical axis the cumulative share of listed institutions. The diagonal represents equal numbers of entries in each jurisdiction, not equal access per person or an equity target. Gini = 0.6914. Source: workforce_lorenz.csv.
