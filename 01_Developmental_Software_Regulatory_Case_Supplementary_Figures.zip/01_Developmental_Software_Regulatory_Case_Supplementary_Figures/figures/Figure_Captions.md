# Figure captions

Licensing Developmental-Support Software in India: An April 2026 Case Study Assessed Against CDSCO’s July 2026 Guidance

## Figure 1. The case and the changing guidance context

Timeline of the April 2026 classification and licensing sequence, followed by public CDSCO software guidance in July and the manufacturer-reported BIS management-system licence in September. The application and licence dates are supported by directly inspected documents; the classification and audit dates are reported in the case account. July guidance is an analytical comparator, not the asserted basis of the April decision. Source details are in Table 1.

## Figure 2. Connected evidence domains with distinct claims

Regulatory authorisation, quality-system controls, technical verification, clinical evaluation, and outcome evidence are connected but answer different questions. Post-market findings feed back into risk management, change control, and further evaluation. No arrow represents equivalence between a licence or certificate and demonstrated clinical benefit. The claim boundaries are specified in Table 3.
