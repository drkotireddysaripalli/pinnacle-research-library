# Supplementary materials

## Accompanying manuscript

**Licensing Developmental-Support Software in India: An April 2026 Case Study Assessed Against CDSCO’s July 2026 Guidance**

Author: Koti Reddy Saripalli.

Package date: 15 September 2026.

Two publication figures and their captions accompany the regulatory case study. The timeline distinguishes directly inspected application/licence documents from dates reported in the case account. The evidence-domain diagram preserves the distinction between regulatory authorisation and demonstrated clinical benefit.

## Contents and use

- `figures/Figure_1` and `figures/Figure_2`: each figure in SVG, EPS, PNG and TIFF formats. SVG and EPS are vector formats; PNG is convenient for viewing; TIFF is a raster publication format.
- `figures/Figure_Captions.md`: exact captions from the final manuscript figure package.
- `SHA256SUMS.txt`: SHA-256 checksums for every other file in this archive, using paths relative to this package folder.

Use these supplements with the accompanying manuscript, which supplies the full methods, interpretation, declarations and references. The repository record supplies the publication identifier and reuse terms for this release.
